function drawGate(v1,v2,v3){
fill(255)
rect((v1[0]+v2[0]+v3[0])/3,(v1[1]+v2[1]+v3[1])/3,150,150)

}
